RRK Quotex Signal Pro — PWA package

এই ZIP-এ আছে:
- মোবাইল-ফ্রেন্ডলি RRK Signal ওয়েব অ্যাপ
- PWA manifest ও service worker
- Home Screen-এ install করার সুবিধা
- Notification permission/test notification
- Web Push event handler (সার্ভার সংযোগের জন্য প্রস্তুত)

গুরুত্বপূর্ণ সীমাবদ্ধতা:
১) এই ZIP নিজে থেকে অ্যাপ বন্ধ থাকলে UP/DOWN সিগন্যাল পাঠাতে পারবে না।
২) Background Push চালু করতে HTTPS hosting, Web Push VAPID keys, subscription database এবং নিরাপদ backend/cron worker লাগবে। এই প্যাকেজে কোনো server credential বা API key নেই; Push backend এখনো যুক্ত করা হয়নি।
৩) Notification test বাটন শুধু permission ও test notification পরীক্ষা করে। অ্যাপ খোলা থাকলে নতুন UP/DOWN signal এলে notification দিতে পারে।
৪) PWA install ও service worker-এর জন্য HTTPS domain প্রয়োজন (localhost ছাড়া)।
৫) Twelve Data API key Settings-এ ব্যবহারকারীকে একবার দিতে হবে; এটি browser/device-এ থাকে।
৬) Twelve Data Forex data Quotex official data নয়; OTC নেই; signal লাভ নিশ্চিত করে না।

ইনস্টল করার সাধারণ ধাপ:
- ZIP-টি HTTPS hosting-এ publish করুন (যেমন GitHub Pages/সমমানের static hosting)।
- Android Chrome-এ সাইট খুলুন।
- Chrome menu (⋮) > Install app / Add to Home screen চাপুন।
- অ্যাপ খুলে Settings-এ Twelve Data API Key দিন।
- Notification Settings > Enable / Test Notification চাপুন এবং Allow দিন।

অ্যাপ বন্ধ অবস্থায় আসল UP/DOWN push notification চালু করতে backend সেটআপ বাকি।
