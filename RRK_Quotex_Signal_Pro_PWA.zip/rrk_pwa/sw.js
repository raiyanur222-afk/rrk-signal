const CACHE = 'rrk-signal-v1';
const FILES = ['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png'];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES))));
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request).then(response => {
    const copy=response.clone(); caches.open(CACHE).then(c=>c.put(event.request,copy)); return response;
  }).catch(()=>cached)));
});
// Remote push notifications can be displayed here once a Push API server is connected.
self.addEventListener('push', event => {
  let data = {title:'RRK Signal', body:'নতুন সিগন্যাল এসেছে।'};
  try { if (event.data) data = {...data, ...event.data.json()}; } catch (_) {}
  event.waitUntil(self.registration.showNotification(data.title || 'RRK Signal', {
    body: data.body || 'নতুন UP/DOWN সিগন্যাল', icon:'./icon-192.png', badge:'./icon-192.png', data:{url:'./'}
  }));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(list => {
    for (const client of list) if ('focus' in client) return client.focus();
    return self.clients.openWindow('./');
  }));
});
